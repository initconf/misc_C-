/*----------------------------------------------------------------
Copyright (c) 2015 Author: Jagadeesh Vasudevamurthy
file: ddeque.hpp

-----------------------------------------------------------------*/

/*----------------------------------------------------------------
This file has class definition
-----------------------------------------------------------------*/

/*----------------------------------------------------------------
Definition of routines of ddeque class
-----------------------------------------------------------------*/

/*----------------------------------------------------------------
WRITE CODE IN THIS FILE
-----------------------------------------------------------------*/
#include "ddeque.h"

template <typename T>
ddeque<T>::ddeque():_frontq(),_rearq(), _front_f(0), _front_r(0), _rear_f(0), _rear_r(0)
{
    if (_display)
    {
        cout << "Inside ddeque constructor" << endl ;
    }
}


template <typename T>
ddeque<T>::ddeque(T c, bool d):_frontq(c, d),_rearq(c, d), _front_f(0), _front_r(0), _rear_f(0), _rear_r(0)
{
    if (d)
    {
        cout << "Inside ddeque constructor" << endl ;
    }
}

template <typename T>
ddeque<T>::ddeque(bool d):_frontq(d),_rearq(d), _front_f(0), _front_r(0), _rear_f(0), _rear_r(0)
{
    if (d)
    {
        cout << "Inside ddeque constructor 2" << endl ;
    }
    
}



template <typename T>
ddeque<T>::~ddeque()
{
    if (display())
    {
        cout << "inside ddeque destructor" << endl ;
        
    }
    
    _front_f = 0 ;
    _rear_r = 0 ;
    
    _front_f = 0;
    _rear_r = 0 ;
}



/// copy constructor and equal operator

//template <typename T>
//ddeque<T>::ddeque(const ddeque<T>& s)
//{
//    
//    
//}
//
//
//template <typename T>
//ddeque<T>& ddeque<T>::operator=(const ddeque<T>& rhs)
//{
//    
//    
//}

template <typename T>
int ddeque<T>::size()
{
//        return _frontq.size() + _rearq.size() ;
    return (_front_r - _front_f)  + (_rear_r - _rear_f) ;
}


template <typename T>
bool ddeque<T>::empty()
{
    if ((_front_f == _front_r) && (_rear_f == _rear_r))
        return true ;
    
    return false ;
}


/// ddqueue operations

// -- Returns first element of the ddeque
template <typename T>
T& ddeque<T>::front()
{
    if (empty())
        assert(0);
    
    return _frontq[_front_r-1];
    
}

// -- Returns last  element of the ddeque
template <typename T>
T& ddeque<T>::back()
{
    if (empty())
        assert(0);
    
    return _rearq[_rear_r - 1];
}


//  -- v is inserted as the first element of the ddeque
template <typename T>
void ddeque<T>::push_front(const T v)
{
    _frontq[_front_r++] = v;
}

// -- v is inserted as the back element of the ddeque
template <typename T>
void ddeque<T>::push_back ( const T v)
{
    _rearq[_rear_r++] = v ;
}

// - First element of the ddeque is removed. Nothing is returned
template <typename T>
void ddeque<T>::pop_front()
{
 
    _front_f+= 1;
}


// - Last element of the ddeque is removed. Nothing is returned
template <typename T>
void ddeque<T>::pop_back()
{
    _rear_r += 1;
}


/// subscript operators
template <typename T>
const T ddeque<T>::operator[]( int i ) const
{
    if ( i < _front_r)
        return _frontq[_front_r -1 - i];
    else if ( i >= _front_r   && i < _front_r + _rear_r)
        return _rearq[i - _front_r ];
}


template <typename T>
T& ddeque<T>::operator[](int i)
{
    if ( i < _front_r)
        return _frontq[_front_r -1 - i];
    else if ( i >= _front_r   && i < _front_r + _rear_r)
        return _rearq[i - _front_r ];
    
    return _frontq[0] ;
    
}



