//
//  p1.h
//  c++
//
//  Created by Aashish Sharma on 6/22/15.
//  Copyright (c) 2015 Aashish Sharma. All rights reserved.
//

#ifndef c___p1_h
#define c___p1_h

#include "../util/util.h"

/*-----------------------------------------
 declearation of datatype class
 -----------------------------------------*/

class p1{
public:
    void print_usa();
    void print_n_n2_n3();
    void a_power_b();
    void two_power_n();
    
    void a1();
    void a2();
    void a3();
    void a4();
    
   
    
private:
    int a_pow_b(int a, int b);
    
};


#endif
