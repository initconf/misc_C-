//
//  collatz.h
//  c++
//
//  Created by Aashish Sharma on 6/22/15.
//  Copyright (c) 2015 Aashish Sharma. All rights reserved.
//

#ifndef COLLATZ_H
#define COLLATZ_H

#include "../util/util.h"

/*-----------------------------------------
 declearation of datatype class
 -----------------------------------------*/

class collatz{

public: 
	int get_collatz(int num);
	void print_seq(int num); 
private:

} ; 



#endif 
